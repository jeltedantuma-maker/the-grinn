# THE GRINN — eigen server

Deze server doet drie dingen:
1. Hij laat de game zien: iedereen opent gewoon jouw link, niks downloaden.
2. Hij verbindt spelers voor samen spelen (werkt ook op school-/bedrijfswifi).
3. Hij toont een lijst met open games ("Open games") en verstuurt vriend-uitnodigingen.

## Op Render.com zetten (gratis)

### Stap 1 — GitHub
1. Maak een gratis account op https://github.com
2. Klik rechtsboven op **+** → **New repository**. Naam: `the-grinn`. Kies **Public**. Klik **Create repository**.
3. Klik op **uploading an existing file**.
4. Pak deze zip uit en sleep de bestanden erin: `server.js`, `package.json`, `render.yaml` en de map `public` (met `index.html` erin).
5. Klik onderaan op **Commit changes**.

### Stap 2 — Render
1. Ga naar https://render.com en klik **Get Started** → log in **met GitHub**.
2. Klik **New +** → **Web Service** → kies je repository `the-grinn` → **Connect**.
3. Vul in (meestal staat het er al):
   - Runtime: **Node**
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Instance Type: **Free**
4. Klik **Deploy Web Service**. Wacht tot er **Live** staat (1–3 minuten).
5. Bovenaan staat jouw link, zoiets als `https://the-grinn-xxxx.onrender.com`. Dat is je game!

Stuur die link naar je vrienden. Host een spel; je vrienden zien het in **Open games** of vullen de code in.

### Goed om te weten
- Gratis servers gaan slapen na 15 minuten zonder spelers. De eerste keer daarna duurt het laden ~1 minuut.
- Nieuwe versie van de game? Vervang `public/index.html` op GitHub (Add file → Upload files). Render zet hem dan vanzelf online.
- Wie het gedownloade bestand gebruikt, kan ook jouw server gebruiken: Samen spelen → Game server → vul je link in → **Use**.

## Op je eigen computer (testen)
Installeer Node.js (https://nodejs.org), open een terminal in deze map en typ:
```
npm install
npm start
```
Open dan http://localhost:8080
